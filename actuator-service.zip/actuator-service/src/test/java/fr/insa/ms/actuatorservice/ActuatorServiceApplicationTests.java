package fr.insa.ms.actuatorservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActuatorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
