package fr.insa.ms.historyservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HistoryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
