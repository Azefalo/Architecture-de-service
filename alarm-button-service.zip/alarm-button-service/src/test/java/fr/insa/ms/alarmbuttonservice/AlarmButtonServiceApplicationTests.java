package fr.insa.ms.alarmbuttonservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlarmButtonServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
