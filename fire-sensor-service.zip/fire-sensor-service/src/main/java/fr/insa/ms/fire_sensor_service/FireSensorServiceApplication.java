package fr.insa.ms.fire_sensor_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FireSensorServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FireSensorServiceApplication.class, args);
	}

}
