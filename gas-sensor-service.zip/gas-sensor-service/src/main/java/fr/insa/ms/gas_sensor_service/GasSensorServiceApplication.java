package fr.insa.ms.gas_sensor_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GasSensorServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GasSensorServiceApplication.class, args);
	}

}
