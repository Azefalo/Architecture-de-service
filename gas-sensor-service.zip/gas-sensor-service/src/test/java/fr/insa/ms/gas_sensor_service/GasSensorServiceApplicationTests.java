package fr.insa.ms.gas_sensor_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GasSensorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
