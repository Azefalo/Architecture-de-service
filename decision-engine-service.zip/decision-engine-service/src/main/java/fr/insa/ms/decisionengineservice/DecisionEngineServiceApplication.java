package fr.insa.ms.decisionengineservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DecisionEngineServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DecisionEngineServiceApplication.class, args);
	}

}
